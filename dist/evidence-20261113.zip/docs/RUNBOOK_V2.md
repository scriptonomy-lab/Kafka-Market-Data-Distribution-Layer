# Runbook v2 — recording the live evidence

The exact sequence for one evidence session on the v2 topology (three
topics, TimescaleDB, Docker, Storage scale-out). Follow it top to bottom; every
number in the README must come from the `summary.json` files this produces.

**When:** a US trading day, **09:45–11:30 New York time** (14:45–16:30 UTC
until 2027-03-14, while New York is on EST). All three asset classes tick
then: FX (24/5), crypto (24/7) and US stocks (09:30–16:00 New York). Avoid
the first 15 minutes after the open and US market holidays (2026: Thanksgiving
Thu 26 Nov closed, Fri 27 Nov closes early; Christmas Fri 25 Dec closed).

**Time needed:** about 45 minutes: 15 to prepare, about 22 of experiments
(F ≈ 10 min, B ≈ 10 min, D ≈ 1 min), the rest for audits and screenshots.

**Keep the host awake.** On battery, macOS may idle-sleep after one minute;
a sleep suspends Docker and the runner's clock mid-experiment and makes the
run invalid (it happened on 2026-11-13: `results/_aborted/`). Plug in, keep
the lid open, and prefix every experiment with `caffeinate -dims`, e.g.
`caffeinate -dims make experiment-f`.

**Rules that apply all session**
- Never run `make capture` or `make fanout-baseline` while the producer
  container runs: one TraderMade session per key (`duplicate_login`).
- Never run `docker compose config`: it prints `.env` values.
- Runs against the simulator (`make up-dev`) land in `results/_dev/` and are
  never evidence. Evidence day uses `make up` (the live feed).

---

## 1. Prepare (09:15–09:45 New York)

```bash
git status                           # clean working tree on the branch you will cite
make reset                           # DANGER: wipes Kafka + TimescaleDB volumes, logs, run state
make up                              # full stack on the LIVE feed, storage x2
make ps                              # all running; kafka + timescaledb healthy; kafka-init + db-init exited 0
make seed-book                       # REST /live entry prices (BTCUSD, ETHUSD, AAPL, FX), restarts risk
make preflight                       # must end with exit 0; read every WARN
```

If 5432 is already used on your machine, put `POSTGRES_HOST_PORT=5433` in
`.env` before `make up` (compose and the host tools both read it).

Preflight should show, before you continue:
- `topic fx / crypto / us_stocks` PASS with 6 partitions each
- `TimescaleDB` PASS (hypertable, migrations 001 and 002)
- `FX market (REST)` open, and `US equity hours (clock)` inside 09:30–16:00
- `partition map` PASS once all 8 symbols have ticked (stocks: after 09:30)

```bash
make partition-map ARGS=--check      # MATCH: observed partition of all 8 symbols = computed
```

```bash
make assignment-check ARGS=--save    # cooperative-sticky: every instance owns data with 2/3 (README cites it)
```

Take screenshots set A now (section 5).

## 2. Experiment F — scale-out and rebalance (09:45, ~10 min)

```bash
caffeinate -dims make experiment-f   # 2 -> 3 instances -> clean stop -> crash, 120 s per step
```

Wait for `Done: ALL CHECKS PASSED`. While it runs, take screenshots set B
(`make logs SVC=storage` shows `assigned` / `revoked` lines as they happen;
`make watch-monitor` shows the members table changing).

Then restore two instances for the next experiment:

```bash
make scale N=2
make ps                              # two storage containers running
```

## 3. Experiment B — crash recovery of the whole Storage group (~10 min)

```bash
caffeinate -dims make experiment-b   # kill ALL storage instances, 300 s outage, restart the same N
```

Wait for `Done`. The runner restarts the same containers itself; Storage is
left running with N instances.

Optional (runnable, not required for the README): `make experiment-a` (clean
stop of all instances), `make experiment-c` (slow sink).

## 4. Experiment D — replay of all three topics (~1 min)

```bash
make replay
```

## 5. Screenshots (save under `docs/evidence/`, with the tmux clock visible)

`make demo` opens the tmux layout over the running containers (status bar
clock). `make watch-*` attaches to one table; detach with **Ctrl-p Ctrl-q**
(Ctrl-c in an attached pane is not forwarded, but detaching is cleaner).

| # | File | What | How |
| --- | --- | --- | --- |
| A1 | `v2-01-compose-ps.png` | every service up, kafka + timescaledb healthy, jobs exited 0 | `make ps` |
| A2 | `v2-02-topics.png` | three topics, 6 partitions each, per-topic retention | `make topics` |
| A3 | `v2-03-producer-routing.png` | `login_ok` (masked key), `sub_ack` with the 8 codes, `partition_map` lines per topic, `published_by_topic` | `make logs SVC=producer` |
| A4 | `v2-04-pricing.png` | FX, crypto and stock rows updating | `make watch-pricing` |
| A5 | `v2-05-risk.png` | FX, BTCUSD and AAPL positions marked | `make watch-risk` |
| A6 | `v2-06-monitor.png` | lag per topic, members and their partitions, ingress per topic | `make watch-monitor` |
| A7 | `v2-07-preflight.png` | preflight with exit 0 | `make preflight` |
| B1 | `v2-08-describe-2-instances.png` | `--members --verbose` with 2 members | F writes `describe_1_steady_before.txt`; screenshot `make describe-groups` |
| B2 | `v2-09-describe-3-instances.png` | after scale-out | `describe_2_scale_out_after.txt` |
| B3 | `v2-10-describe-after-stop.png` | after the clean stop | `describe_3_clean_stop_after.txt` |
| B4 | `v2-11-describe-after-crash.png` | after the crash and session timeout | `describe_4_crash_after.txt` |
| B5 | `v2-12-storage-assigned-revoked.png` | `assigned` / `revoked` / `resumed` lines with instance ids | `make logs SVC=storage` during F |
| C1 | F charts | ownership timeline, lag per topic, throughput per instance | `results/<F run>/ownership.png`, `lag_by_topic.png`, `throughput.png` (files, no screenshot needed) |
| C2 | B summary | no loss per topic, isolation per topic, resume points | `results/<B run>/summary.md` |
| C3 | D summary | replay vs TimescaleDB per topic | `results/<D run>/summary.md` |

The `describe_*.txt` files are the evidence; B1–B4 are the same views as images.

## 6. After the runs

```bash
# audit each run (Claude Code slash command): recompute and cross-check
/evidence-audit results/<F run>
/evidence-audit results/<B run>
/evidence-audit results/<D run>

make test-report                     # results/<stamp>-tests/ (unit + integration + lint)
make evidence-bundle                 # dist/evidence-<date>.zip (no raw ticks, no keys, no price logs)
```

Then regenerate the README results tables from the three new `summary.json`
files only (each value cites its run id), and commit the result folders,
`docs/evidence/` and the README together.

## If something goes wrong

| Symptom | Cause | Fix |
| --- | --- | --- |
| producer logs `logout: duplicate_login` | another process logged in with the key | stop it; the producer reconnects after 30 s |
| preflight FAIL `topic ...` partition count | old volume from v1 | `make reset && make up` |
| F stuck in `setup` | Storage not caught up or not 2 members | `make ps`, `make logs SVC=storage`; `make scale N=2` |
| stock rows missing in Pricing | outside US market hours | record 09:45–11:30 New York |
| `FX market is closed` | weekend | wait for the FX open (Sunday 17:00 New York) |
| a run's timestamps jump / it stalls mid-step | the host slept (check `pmset -g log`) | discard the run (move it to `results/_aborted/` with a note) and rerun under `caffeinate -dims` |
