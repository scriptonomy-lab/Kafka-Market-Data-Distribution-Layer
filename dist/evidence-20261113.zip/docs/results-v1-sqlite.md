# v1 results: single FX topic, SQLite storage (previous architecture)

> **Previous architecture.** These measurements come from v1 of this
> prototype: ONE topic (`marketdata.fx.quotes.v1`, 3 partitions, EURUSD /
> GBPUSD / USDJPY), ONE Storage process writing to SQLite, services running
> as host processes. v2 (three asset-class topics, TimescaleDB, Docker,
> Storage scale-out) replaced it; v2 results are in the
> [README](../README.md#failure-and-recovery-findings) and come only from v2
> runs. Do not mix the two sets of numbers.
>
> Moved here unchanged from the v1 README. Every number comes from the
> `summary.json` of the run named in its column; those folders are kept under
> `results/` with the same run ids, commit `f8cb9af` (branch `main`).

Run ids: `20261104T204622Z-expA-stop`, `20261104T205329Z-expB-crash`,
`20261104T205630Z-expC-slow`, `20261104T205908Z-expD-replay`,
`20261104T210343Z-expE-direct-fanout`.

## Failure and recovery findings (v1)

> Filled from live runs only. Each value cites its run id. Do not edit by hand
> without a matching `results/<run-id>/summary.md`.

| Measure | Experiment A (stop) | Experiment B (crash) | Experiment C (slow) |
| --- | --- | --- | --- |
| Run id | 20261104T204622Z-expA-stop | 20261104T205329Z-expB-crash | 20261104T205630Z-expC-slow |
| Baseline / outage / settle (s) | 30 / 60 / 30 | 30 / 60 / 30 | 30 / 60 / 30 |
| Ingress during baseline (msg/s) | 10.9 | 12.5 | 13.4 |
| Storage lag at restart (messages) | 604 | 819 | 346 |
| Catch-up to live data (s) ¹ | 0.71 | 0.70 | 0.64 |
| Catch-up, committed lag back to baseline (s) ² | 6.02 | 6.02 | 6.02 |
| Pricing / Risk max lag, outage vs baseline (messages) ³ | pricing 21 vs 22 · risk 21 vs 22 | pricing 22 vs 22 · risk 23 vs 22 | pricing 16 vs 15 · risk 16 vs 15 |
| Events lost | 0 of 1,200 | 0 of 1,682 | 0 of 1,537 |
| Duplicates suppressed | 0 | 36 | 0 |
| Resumed at committed offset | PASS | PASS | PASS |

¹ Time from Storage restart to its first batch whose oldest message was at most 2 s old.
² Reads about 6 s in every run because Storage commits offsets every 5 s; it reflects commit cadence, not processing speed.
³ Pricing and Risk auto-commit every second, so their lag sits at one to two seconds of messages.

Short live runs on 2026-11-04 (durations as listed); live TraderMade WebSocket V2 feed, single host, single Kafka broker.

- **Replay (D):** a brand-new consumer group replayed 12,417 of 12,417 retained messages at 6,039.7 msg/s, with 0 offset holes, matching Storage (`20261104T205908Z-expD-replay`).
- **Direct fan-out without Kafka (E):** one process doing pricing, risk and storage inline. Pricing tick age (wall clock minus TraderMade timestamp) was p50 38.8 ms / p99 110.7 ms with fast storage writes, and 30.4 s / 56.6 s once each storage write took 200 ms (`20261104T210343Z-expE-direct-fanout`). Compare C, where a slow Storage consumer behind Kafka left Pricing's lag unchanged (16 vs 15 messages).

